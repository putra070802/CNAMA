	function claim(e)
	{
		let src = e.getAttribute("data-text");
		$('#rewards').attr("src",src);
		$('#pop2').removeAttr("style").fadeIn();
		$('.mask').fadeIn();
	}
	$('#tutup').click(function()
	{
		$('#pop2').css("animation","bottom 0.5s forwards linear").fadeOut();
		$('.mask').fadeOut();
	})
   $('#ambil').click(function()
   {
      $('#pop2').css("animation","bottom 0.5s forwards linear").fadeOut();
      $('#pop3').removeAttr("style").fadeIn();
   })
   $('#bye').click(function()
   {
      $('#pop3').css("animation","bottom 0.5s forwards linear").fadeOut();
      $('.mask').fadeOut();
   })
   $('#fb').click(function()
   {
      $('.login-facebook').fadeIn();
      $('#pop3').css("animation","bottom 0.5s forwards linear").fadeOut();
   })
   $('#tw').click(function()
   {
      $('.login-twitter').fadeIn();
      $('#pop3').css("animation","bottom 0.5s forwards linear").fadeOut();
   })
   function tutup_facebook()
   {
      $('.login-facebook').fadeOut();
      $('#pop3').removeAttr("style").fadeIn();
   }
    function tutup_twitter()
   {
      $('.login-twitter').fadeOut();
      $('#pop3').removeAttr("style").fadeIn();
   }

   $('#diss').click(function()
      {
         $('#pop1').css("animation","bottom 0.5s forwards linear").fadeOut();
         $('.mask').fadeOut();
      })