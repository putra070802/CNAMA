$(document).ready(function()
{
	$('.sel').click(function(){
		let id = $(this).attr("id");
		if(id == "outfit")
		{
			$('.load').load('pages/outfit.php');
		}
		else if(id == "weapon")
		{
			$('.load').load('pages/weapon.php');
		}
		else if(id == "shop")
		{
			$('.load').load('pages/pharoah.php');
		}
	})
	$('.load').load('pages/outfit.php');
})