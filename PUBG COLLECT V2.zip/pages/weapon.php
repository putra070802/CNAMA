<div class="skroll">
         <div class="card">
         <img src="img/1.png">
         <button onclick="claim(this)" class="claim" data-text="img/1.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/2.png">
         <button onclick="claim(this)" class="claim" data-text="img/2.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/16.png">
         <button onclick="claim(this)" class="claim" data-text="img/16.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/4.png">
         <button onclick="claim(this)" class="claim" data-text="img/4.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/5.png">
         <button onclick="claim(this)" class="claim" data-text="img/5.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/6.png">
         <button onclick="claim(this)" class="claim" data-text="img/6.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/7.png">
         <button onclick="claim(this)" class="claim" data-text="img/7.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/8.png">
        <button onclick="claim(this)" class="claim" data-text="img/8.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/9.png">
        <button onclick="claim(this)" class="claim" data-text="img/9.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/10.png">
         <button onclick="claim(this)" class="claim" data-text="img/10.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/11.png">
        <button onclick="claim(this)" class="claim" data-text="img/11.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/12.png">
         <button onclick="claim(this)" class="claim" data-text="img/12.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/13.png">
         <button onclick="claim(this)" class="claim" data-text="img/13.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/14.png">
         <button onclick="claim(this)" class="claim" data-text="img/14.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/15.png">
        <button onclick="claim(this)" class="claim" data-text="img/15.png">Claim</button>
     </div>
      <div class="card">
         <img src="img/3.png">
         <button onclick="claim(this)" class="claim" data-text="img/3.png">Claim</button>
      </div>
      <div class="card">
         <img src="img/17.png">
         <button onclick="claim(this)" class="claim" data-text="img/17.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/3cM96Bn/3.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/3cM96Bn/3.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/pdYW33J/12.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/pdYW33J/12.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/YpbSGGN/3.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/YpbSGGN/3.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/v332bhy/4.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/v332bhy/4.png">Claim</button>
      </div>
</div>