<div class="skroll">
                  <div class="card">
                  <img src="https://i.ibb.co/mTpf1bz/3.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/mTpf1bz/3.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/pd4MrC6/4.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/pd4MrC6/4.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/Xjjs6Mv/5.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/Xjjs6Mv/5.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/wwCwgFX/6.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/wwCwgFX/6.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/sVkDgf7/8.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/sVkDgf7/8.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/7v7cDFb/9.jpg">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/7v7cDFb/9.jpg">Claim</button>
               </div>
               <div class="card">
                  <img src="https://i.ibb.co/qdC5zHF/5.png">
                  <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/qdC5zHF/5.png">Claim</button>
               </div>
</div>