<div class="skroll">
         <div class="card">
         <img src="https://i.ibb.co/9W3h47v/1.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/9W3h47v/1.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/hMsPMxw/2.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/hMsPMxw/2.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/1TdQprZ/3.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/1TdQprZ/3.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/vscMKsk/4.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/vscMKsk/4.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/s5M6Hfk/5.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/s5M6Hfk/5.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/whLQPwP/6.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/whLQPwP/6.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/KVtTgHb/7.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/KVtTgHb/7.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/f2j82yk/8.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/f2j82yk/8.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/0mK0Kkm/1.jpg">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/0mK0Kkm/1.jpg">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/x70Zv58/2.jpg">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/x70Zv58/2.jpg">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/SfsVZj3/3.jpg">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/SfsVZj3/3.jpg">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/3s4VjWb/13.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/3s4VjWb/13.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/Fb4WYn9/15.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/Fb4WYn9/15.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/Ms6xmw1/22.jpg">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/Ms6xmw1/22.jpg">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/BG71Lq8/1.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/BG71Lq8/1.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/cYLYRnF/2.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/cYLYRnF/2.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/Kmzt1kv/3.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/Kmzt1kv/3.png">Claim</button>
      </div>
      <div class="card">
         <img src="https://i.ibb.co/ySj37hj/4.png">
         <button onclick="claim(this)" class="claim" data-text="https://i.ibb.co/ySj37hj/4.png">Claim</button>
      </div>
</div>